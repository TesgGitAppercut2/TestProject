﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication_norm
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string b = Request.QueryString["var"];
            string c = Request.Form["var"];
            bool d = Request.IsAuthenticated;
        }
    }
}
