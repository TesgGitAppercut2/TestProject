package CryptoWeakCryptographicAlgorithm.vulnerable;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import java.security.Key;

public class V_WeakCryptographicAlgorithm_vuln00
{
	private final Key key;

	public V_WeakCryptographicAlgorithm_vuln00( Key key )
	{
		this.key = key;
	}

	public byte[] encrypt(String password)
	{
		try
		{
			Cipher des = Cipher.getInstance( "DES" );
			des.init( Cipher.ENCRYPT_MODE, key );
			return des.doFinal( password.getBytes() );
		} catch( Throwable ex )
		{
			throw new IllegalStateException( ex );
		}
	}

	public String decrypt(byte[] encrypted)
	{
		try {
			Cipher des = Cipher.getInstance( "DES" );
			des.init( Cipher.DECRYPT_MODE, key );
			return new String(des.doFinal( encrypted ));
		} catch( Throwable ex )
		{
			throw new IllegalStateException( ex );
		}
	}

	public static void main(String[] args)
	{
		String keyString = "Example key needs to be 8 chars long";
		V_WeakCryptographicAlgorithm_vuln00 obj =
				new V_WeakCryptographicAlgorithm_vuln00( generateKey( keyString ) );
		byte[] encrypt = obj.encrypt( "show me" );
		System.out.println(obj.decrypt( encrypt ));
	}

	public static Key generateKey(String keyString)
	{
		try
		{
			DESKeySpec keySpec = new DESKeySpec( keyString.getBytes() );
			SecretKeyFactory skf = SecretKeyFactory.getInstance("DES");
			return skf.generateSecret(keySpec);
		} catch( Throwable ex )
		{
			throw new IllegalStateException( ex );
		}
	}

}
