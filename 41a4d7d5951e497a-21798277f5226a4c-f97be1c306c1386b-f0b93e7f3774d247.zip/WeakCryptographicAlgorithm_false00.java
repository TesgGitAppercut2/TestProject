package CryptoWeakCryptographicAlgorithm.normal;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import java.security.Key;

public class WeakCryptographicAlgorithm_false00
{
	private final Key key;

	public WeakCryptographicAlgorithm_false00( Key key )
	{
		this.key = key;
	}

	public byte[] encrypt(String password)
	{
		try
		{
			Cipher des = Cipher.getInstance( "AES" );
			des.init( Cipher.ENCRYPT_MODE, key );
			return des.doFinal( password.getBytes() );
		} catch( Throwable ex )
		{
			throw new IllegalStateException( ex );
		}
	}

	public String decrypt(byte[] encrypted)
	{
		try {
			Cipher des = Cipher.getInstance( "AES" );
			des.init( Cipher.DECRYPT_MODE, key );
			return new String(des.doFinal( encrypted ));
		} catch( Throwable ex )
		{
			throw new IllegalStateException( ex );
		}
	}

	public static void main(String[] args)
	{
		WeakCryptographicAlgorithm_false00 obj =
				new WeakCryptographicAlgorithm_false00( generateKey() );
		byte[] encrypt = obj.encrypt( "show me the monkey" );
		System.out.println(obj.decrypt( encrypt ));
	}

	public static Key generateKey()
	{
		try
		{
			KeyGenerator kgen = KeyGenerator.getInstance("AES");
			kgen.init(128);
			return kgen.generateKey();
		} catch( Throwable ex )
		{
			throw new IllegalStateException( ex );
		}
	}
}
